/*   JSHINT("function(){}")

    var ret = JSHINT.data()
    ret.options = null
    alert(JSON.stringify(ret))
	*/
	function ()
	{
	
	}